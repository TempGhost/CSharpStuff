﻿
namespace ImmutableCollectionsSample
{
  public class Account
  {
    public string Name { get; set; }
    public decimal Amount { get; set; }
  }
}
