﻿
namespace Wrox.ProCSharp.WinServices
{
  public enum ButtonState
  {
    Start,
    Stop,
    Pause,
    Continue
  }
}
