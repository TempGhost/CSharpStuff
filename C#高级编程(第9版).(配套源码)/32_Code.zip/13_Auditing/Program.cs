﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _13_Auditing
{
    class Program
    {
        static void Main(string[] args)
        {
            // No code here - just see the StoredProcs.sql file and run this against the database
        }
    }
}
