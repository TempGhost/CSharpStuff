using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace XmlSample
{
  public partial class frmXMLNav : Form
  {
    public frmXMLNav()
    {
      InitializeComponent();
    }
  }
}