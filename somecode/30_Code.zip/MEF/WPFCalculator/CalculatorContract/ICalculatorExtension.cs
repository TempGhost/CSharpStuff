﻿using System.Windows;
using System.Windows.Media.Imaging;

namespace Wrox.ProCSharp.MEF
{
  public interface ICalculatorExtension
  {
    FrameworkElement UI { get; }
  }
}
