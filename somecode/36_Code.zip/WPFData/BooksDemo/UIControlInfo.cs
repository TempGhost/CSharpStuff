﻿using System.Windows.Controls;

namespace Wrox.ProCSharp.WPF
{
  public class UIControlInfo
  {
    public string Title { get; set; }
    public UserControl Content { get; set; }
  }
}
