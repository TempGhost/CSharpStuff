using System;

namespace Wrox
{
    public class MyFirstClass
    {
        static void Main()
        {
            Console.WriteLine("Hello from Wrox.");
            Console.ReadLine();
            return;
        }
    }
}
