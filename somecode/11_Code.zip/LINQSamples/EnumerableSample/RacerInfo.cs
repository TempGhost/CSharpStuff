﻿
namespace Wrox.ProCSharp.LINQ
{
  public class RacerInfo
  {
    public int Year { get; set; }
    public int Position { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
  }
}
