﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wrox.ProCSharp.Messaging
{
  public class MessageConfiguration
  {
    public bool? HighPriority { get; set; }
  }
}
